export class UserDashboard{
    id=0;
    fName:any='';
    lName:any='';
    email:any='';
    mob:any='';
    salary:any='';
}